document.addEventListener('DOMContentLoaded', () => {
    console.log('Uçuş Takvim Sistemi yüklendi!');

    // Örnek uçuş verileri
    const flights = [
        { flightNumber: 'TK123', destination: 'İstanbul', date: '2025-11-01' },
        { flightNumber: 'LH456', destination: 'Berlin', date: '2025-11-02' },
        { flightNumber: 'AF789', destination: 'Paris', date: '2025-11-03' }
    ];

    // Giriş formunu işleme
    const loginForm = document.getElementById('login-form');
    loginForm.addEventListener('submit', (event) => {
        event.preventDefault(); // Formun varsayılan davranışını engelle

        // Kullanıcı adı ve şifreyi al
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;

        // Basit bir kontrol (örnek olarak)
        if (username === 'admin' && password === '1234') {
            alert('Giriş başarılı!');
            // Uçuş listesini göster
            const flightListDiv = document.getElementById('flight-list');
            flightListDiv.style.display = 'block';
            flights.forEach(flight => {
                const flightItem = document.createElement('div');
                flightItem.innerHTML = `<strong>Uçuş No:</strong> ${flight.flightNumber}, <strong>Varış:</strong> ${flight.destination}, <strong>Tarih:</strong> ${flight.date}`;
                flightListDiv.appendChild(flightItem);
            });
            // Giriş formunu gizle
            loginForm.style.display = 'none';
        } else {
            alert('Kullanıcı adı veya şifre hatalı!');
        }
    });
});
